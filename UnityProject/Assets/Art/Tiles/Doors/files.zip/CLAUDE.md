# STATION BUILDER — PROJECT INSTRUCTIONS
# For VS Code / GitHub Copilot / Claude Code
# Place this file at your project root (same folder as Assets/)

---

## PROJECT OVERVIEW

Top-down 2D sci-fi station builder in Unity. Visual language: RimWorld / Prison Architect.
Fixed north camera. Tile-based grid. NPCs navigate rooms. Player builds and manages a station.

---

## DOOR SYSTEM — COMPLETE REFERENCE

### Files (all in Assets/Art/Tiles/Doors/ unless noted)

| File | Location | Purpose |
|------|----------|---------|
| `door_ns_atlas.png` | Art/Tiles/Doors/ | Sprite atlas PNG — 792×66px RGBA |
| `door_ns_atlas.png.meta` | Art/Tiles/Doors/ | Unity import settings — DO NOT EDIT MANUALLY |
| `DoorAtlasData.cs` | Scripts/World/ | ScriptableObject holding sprite references |
| `DoorRenderer.cs` | Scripts/World/ | MonoBehaviour — drives animation and health states |
| `DoorAtlasSetup.cs` | Editor/ | Editor tool — run once after importing PNG |

### Atlas Layout — 12 sprites, single row, 64×64 each in 66×66 slots

```
Col  0  door_ns_open0     0%   closed
Col  1  door_ns_open1    11%
Col  2  door_ns_open2    22%
Col  3  door_ns_open3    33%
Col  4  door_ns_open4    44%
Col  5  door_ns_open5    56%
Col  6  door_ns_open6    67%
Col  7  door_ns_open7    78%
Col  8  door_ns_open8    89%
Col  9  door_ns_open9   100%  fully open
Col 10  door_ns_damaged        hp <= 50%
Col 11  door_ns_destroyed      hp = 0
```

Sprite rects (Unity Y bottom-up, atlas height = 66):
  x = col * 66 + 1
  y = 1   (= 66 - 1 - 64, always)
  w = 64, h = 64

### Geometry (pixel coordinates within each 64×64 tile)

```
JW  = 6    jamb width each side
TH  = 5    top threshold height
BH  = 4    bottom threshold height
PX0 = 6    passage left  edge (= JW)
PX1 = 57   passage right edge (= T-1-JW)
PW  = 52   passage width
PY0 = 5    passage top    (= TH)
PY1 = 49   passage bottom (= TS-1-BH, TS=54)
TS  = 54   top surface height (= T-FH)
FH  = 10   south face strip height (y=54..63)
```

Passage void = transparent pixels at x=PX0..PX1, y=PY0..PY1.
Face strip passage gap = transparent at x=PX0..PX1, y=TS+1..T-2 (always, all states).
Door leaf slides WEST into jamb pocket. Leading edge is on the right (east) side.

### Open fraction → sprite index

```csharp
int spriteIndex = Mathf.RoundToInt(Mathf.Clamp01(fraction) * 9);
// 0.0 → index 0  (closed)
// 0.5 → index 5  (56% open)
// 1.0 → index 9  (fully open)
```

### Orientation

NS door (wall runs N↔S, passage E↔W): transform.rotation = Quaternion.identity
EW door (wall runs E↔W, passage N↔S): transform.rotation = Quaternion.Euler(0, 0, 90)
No separate EW atlas needed — rotation handles it.

### Health states

```
hp > 0.5  → DoorHealthState.Normal    → animate with open stages 0-9
hp <= 0.5 → DoorHealthState.Damaged   → show col 10, door stuck closed
hp == 0   → DoorHealthState.Destroyed → show col 11, jammed open ~38%
```

### DoorRenderer public API

```csharp
door.Open(speed: 3f);                  // animate to 100% (full travel ~0.33s)
door.Close(speed: 3f);                 // animate to 0%
door.AnimateTo(0.5f, speed: 3f);       // animate to any fraction
door.SetOpenFraction(0.75f);           // instant snap, no animation
door.SetHealthFromNormalised(hp/maxHp);// auto-selects Normal/Damaged/Destroyed
door.SetOrientation(DoorOrientation.EW); // rotates transform 90° Z
```

### Setup procedure (run ONCE after importing PNG)

1. Place door_ns_atlas.png in Assets/Art/Tiles/Doors/
2. Place DoorAtlasSetup.cs in Assets/Editor/
3. Unity menu → Tools → Door → Setup Door Atlas
4. This sets import settings, slices sprites, fills DoorAtlasData, creates anim clips
5. Attach DoorRenderer.cs to door GameObjects and assign DoorAtlasData asset

### Important: door replaces wall tile

A door tile sits AT the wall grid cell — do NOT render a wall tile underneath it.
The door frame uses the same bevel/grout/rivet visual language as wall tiles.
Sorting layer: Walls, order 2 (above wall base=0 and wall overlay=1).

---

## WALL SYSTEM — COMPLETE REFERENCE

### Files

| File | Location | Purpose |
|------|----------|---------|
| `wall_atlas.png` | Art/Tiles/Walls/ | 1056×66px, 16 sprites |
| `wall_shadow_atlas.png` | Art/Tiles/Walls/ | 66×66px, 1 sprite |
| `WallAtlasData.cs` | Scripts/World/ | ScriptableObject |
| `WallRenderer.cs` | Scripts/World/ | MonoBehaviour |

### Three-layer render order (back to front)

```
1. Shadow  wall_shadow_atlas col 0 — on floor tile ONE CELL SOUTH of wall
           only when south neighbour is open exterior space
           Sorting: Floor layer, order 10

2. Base    wall_atlas col 0 (wall_solid_normal) — fully opaque 64×64
           all four edges identical, no face strip, no direction
           Sorting: Wall layer, order 0

3. Overlay wall_atlas col 1-15 — transparent 64×64
           selected by interior adjacency bitmask
           Sorting: Wall layer, order 1
```

### Interior overlay bitmask

```
N = 8  (grid-north neighbour is interior floor)
S = 4  (grid-south neighbour is interior floor) ← triggers face strip
E = 2  (grid-east  neighbour is interior floor)
W = 1  (grid-west  neighbour is interior floor)

overlayCol = (N?8:0) | (S?4:0) | (E?2:0) | (W?1:0)
Value 0 = no interior neighbours → skip overlay entirely
```

### Y-axis coordinate warning

Grid Y increases DOWNWARD (row 0 = top of map).
Grid-north = row-1 = world +Y (higher on screen).
The face strip appears on the SOUTH face (visually bottom of screen).

In WallRenderer, swap N↔S when building the bitmask from grid neighbours:
```csharp
int mask = (gridSouth ? 8 : 0)  // grid-south = world -Y = visually south = atlas N bit? NO:
         | (gridNorth ? 4 : 0)  // Wait — face strip is on atlas S=4 bit
         ...
```
Correct mapping for Y-DOWN grid:
```csharp
// "interiorNorth" means grid row-1 (world +Y, visually UP = atlas north)
// "interiorSouth" means grid row+1 (world -Y, visually DOWN = atlas south = face strip)
int mask = (interiorNorth ? 8 : 0)
         | (interiorSouth ? 4 : 0)   // S=4 triggers face strip
         | (interiorEast  ? 2 : 0)
         | (interiorWest  ? 1 : 0);
```
The earlier N↔S swap was wrong. Use the above directly.

### WallRenderer public API

```csharp
wall.SetNeighbours(n, s, e, w, shadowSouth);
// n/s/e/w: bool — is that grid neighbour interior floor?
// shadowSouth: bool — is grid-south neighbour open exterior? (enables shadow)
```

---

## SPRITE & ATLAS RULES (apply to ALL sprites in project)

- Filter mode: Point — ALWAYS
- Compression: None — ALWAYS
- Mipmaps: disabled — ALWAYS
- Pixels Per Unit: 64 — ALWAYS
- Wrap mode: Clamp — ALWAYS
- Texture type: Sprite, Multiple
- Alpha is transparency: true
- Mesh type: FullRect (never Tight)
- Pivot: centre (0.5, 0.5)
- Tile size: 64×64, slot size: 66×66 (1px transparent padding all sides)
- Sprite rect Y in Unity = atlasHeight - 1 - 64 (bottom-up coordinate)
- NEVER manually edit .meta files — always use Editor setup scripts
- NEVER use Unity's auto-slicer — always use explicit SpriteMetaData rects

---

## GRID & COORDINATE SYSTEM

- Grid origin: top-left (0,0)
- X increases east (right)
- Y increases south (DOWN) — Y-DOWN grid
- World position: Vector3(col, -row, 0)
- One cell = one Unity world unit = 64px at PPU 64
- "North" in grid = row-1 = world +Y (visually up)
- "South" in grid = row+1 = world -Y (visually down, where face strip appears)
- All neighbour queries use grid (col, row) coordinates

---

## SORTING LAYERS (back to front)

```
Void         scene background
Floor        floor tiles
FloorShadow  wall drop shadows (order 10)
Walls        wall base (0), wall overlay (1), doors (2)
Furniture    furniture base
NPCs         NPC sprites
FurnitureTop furniture tops that occlude NPCs
UI           world-space UI
```

---

## C# CONVENTIONS

- Namespace: StationBuilder (sub-namespaces: StationBuilder.World, StationBuilder.UI)
- ScriptableObjects: suffix Data (DoorAtlasData, WallAtlasData)
- Editor scripts: Assets/Editor/, suffix Setup or Editor
- Enums: append-only, never reorder/remove existing values
- Feature flags: [SerializeField] bool _featureEnabled = true on all major features
- OnValidate() should call Apply() for immediate inspector feedback
- No magic numbers — use named constants or ScriptableObject fields

---

## UI SYSTEM

Unity UI Toolkit (UXML + USS). NOT uGUI/Canvas.
Reference files: BuildMenu.uxml, BuildMenu.uss, Shared.uss, BuildMenuController.cs
Palette, typography, and component rules: see UI_STYLE_GUIDE.md

---

## WHEN ADDING A NEW TILE TYPE

1. Generate atlas PNG via HTML pixel-renderer tool
2. Write Assets/Editor/[Name]AtlasSetup.cs (copy DoorAtlasSetup.cs pattern)
3. Write Assets/Scripts/World/[Name]AtlasData.cs (ScriptableObject)
4. Write Assets/Scripts/World/[Name]Renderer.cs (MonoBehaviour)
5. Run setup via Tools menu
6. Update this CLAUDE.md with the new system's reference section

---

## DO NOT

- Do not render a wall tile under a door tile
- Do not edit .meta files manually
- Do not use Unity's auto-slicer
- Do not use border-radius in USS (all UI corners are square)
- Do not use Unity Tilemap component (custom tile renderer only)
- Do not use uGUI/Canvas for new UI (UI Toolkit only)
- Do not compress sprite atlases
- Do not enable mipmaps on sprite atlases
- Do not reorder enum values
